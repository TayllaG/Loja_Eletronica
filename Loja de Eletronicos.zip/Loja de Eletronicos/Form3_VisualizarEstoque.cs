﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Metadata;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace Loja_de_Eletronicos
{
    public partial class Form3_VisualizarEstoque : Form
    {
        public Form3_VisualizarEstoque()
        {
        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 menu = new Form1();
            menu.ShowDialog();
        }
    
        private void button2_Click(object sender, EventArgs e)
        {
            
           
        }
       
    }
}

